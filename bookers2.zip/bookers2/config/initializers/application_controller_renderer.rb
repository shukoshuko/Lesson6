# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '0e55b775d720f3744bb8bf2cc49ab20c84ed9022c3b8ca4d067ba62ef061cc05c9d281bf717be06bddf92df27583aac914c0a52aecde2205cd3255dc2bae72f3'